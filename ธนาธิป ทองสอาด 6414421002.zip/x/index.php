<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
     <!-- Option 1: Bootstrap Bundle with Popper -->
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <title>Forrest Gump</title>
</head>
<body>
<?php include 'navbar.php'; ?>
<div style="margin-left:10%; margin-right:10%;">
<div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active" style="height:500px;">
      <img src="img/k.jpg" class="d-block w-100 " alt="...">
    </div>
    <div class="carousel-item" style="height:500px;">
      <img src="img/S_21.jpg" class="d-block w-100 " alt="...">
    </div>
    <div class="carousel-item" style="height:500px;">
      <img src="img/l.jpg" class=" w-100 " alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</div>
<br>
<div class="container alert alert-dark">
  <div class="jumbotron">
    <h1>ฟอร์เรสท์ กัมพ์ อัจฉริยะปัญญานิ่ม</h1>      
    <p>ภาพยนตร์แนวชีวิต - เบาสมอง ที่ออกฉายใน ค.ศ. 1994 แสดงนำโดย ทอม แฮงส์ ที่ประสบความสำเร็จมากเรื่องหนึ่ง ภาพยนตร์เรื่องนี้ สร้างจากนิยายเรื่อง Forrest Gump ที่แต่งโดย วินส์ตัน กรูม (Winston Groom)
</p>
  </div>  
</div>
<div style="margin-left:5%; margin-right:5%;">
<iframe width="560" height="315" src="https://www.youtube.com/embed/TGKBbCsPJ2w" align=left hspace="20" vspace="20" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe><p style="font-size:24px; text-align:center; hspace:20 vspace:20" ><b>ภาพยนตร์เรื่องนี้ ได้รับการจัดอันดับเป็นภาพยนตร์อเมริกันที่สุดตลอดกาล อันดับที่ 71 ทำรายได้กว่า 677 ล้านดอลลาร์สหรัฐ ซึ่งเทียบเท่าเงินกว่า 989 ล้านดอลลาร์สหรัฐในปัจจุบัน ซึ่งมีเพียงภาพยนตร์อมตะอย่างเรื่อง ไททานิก, เดอะลอร์ดออฟเดอะริงส์, แฮร์รี่ พอตเตอร์ ที่เอาชนะยอดนี้ได้</b></p><br clear=left>
</div>
<br><br>
<?php include 'footer.php'; ?>
</body>
</html>