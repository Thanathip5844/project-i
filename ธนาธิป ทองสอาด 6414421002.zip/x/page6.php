<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
     <!-- Option 1: Bootstrap Bundle with Popper -->
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <title>Forrest Gump</title>
</head>
<body style="background-image: url('img/S_2.jpg');background-size: 860px;">
<?php include 'navbar.php'; ?><br>
<div class="container alert alert-dark">
  <div class="jumbotron">
    <h1>คำคม ใน ฟอร์เรสท์ กัมพ์ อัจฉริยะปัญญานิ่ม</h1>      
    <p>ภาพยนตร์เรื่องนี้แฝงไปด้วยแนวคิดต่างๆข้อให้คุณสนุกที่จะรับชมและอินไปด้วยกัน จากธนาธิป ทองสอาด
</p>
  </div> 
  </div>
<div style="margin-top:1%; margin-bottom:5%;">
<div class="row">
<?php
$sql= "SELECT c_id,image1,name_1,epigram
FROM concept
LEFT JOIN  tbl4
ON  concept.c_id = tbl4.a_id";
$result=mysqli_query($conn,$sql);
while($row=mysqli_fetch_array($result)){
?>
<div class="col-sm-6">
    <div class="text-center">
    <br>   
    <img src="img/<?=$row['image1']?>" align=left hspace="20" vspace="20" width="250px" height="250px"><br> <?=$row['epigram']?><br>
    
    <?=$row['name_1']?>
</div>
</div>
<?php
}
mysqli_close($conn);
?>   
<br><br>
</div>
<?php include 'footer.php'; ?>
</body>
</html>