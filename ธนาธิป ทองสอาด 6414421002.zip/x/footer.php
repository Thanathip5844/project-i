<footer class="text-center mt-5 fixed-bottom text-white bg-dark py-1">
&copy; Thanathip&nbsp;&nbsp;&nbsp;
</footer>