-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2023 at 05:50 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `forrest`
--

-- --------------------------------------------------------

--
-- Table structure for table `actor`
--

CREATE TABLE `actor` (
  `id` int(11) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `age` varchar(3) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `chapter` varchar(60) NOT NULL,
  `picture` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `actor`
--

INSERT INTO `actor` (`id`, `firstname`, `lastname`, `age`, `gender`, `chapter`, `picture`) VALUES
(1, 'โทมัส', 'เจฟฟรี่ย์', '29', 'Male', 'พระเอก', '56.jpg'),
(2, 'โรบิน ไรท์', 'เพนน์ ', '29', 'Female', 'นางเอก', '57.jpg'),
(3, 'แกรี่', 'ซินิส ', '30', 'Male', 'เพื่อนพระเอก', '58.jpg'),
(4, 'มายเคลตี', 'วิลเลียมสัน', '30', 'Male', 'เพื่อนพระเอก', '59.jpg'),
(5, 'แซลลี ', ' ฟิลด์', '60', 'Female', 'แม่พระเอก', '60.jpg'),
(6, 'ไมเคิล คอนเนอร์', 'ฮัมฟรีส์ ', '8', 'Male', 'พระเอกตอนเด็ก', '61.jpg'),
(7, 'ฮานนา โรส', 'ฮอลล์ ', '8', 'Female', 'นางเอกตอนเด็ก', '62.jpg'),
(8, 'ฮาลีย์ โจเอล ', 'ออสเมนท์', '8', 'Male', 'ลูกพระเอก', '63.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `concept`
--

CREATE TABLE `concept` (
  `c_id` int(11) NOT NULL,
  `concept1` varchar(60) NOT NULL,
  `detail_con` text NOT NULL,
  `epigram` text NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `concept`
--

INSERT INTO `concept` (`c_id`, `concept1`, `detail_con`, `epigram`, `image`) VALUES
(1, 'ขนนกที่ปลิวมาตกที่ขาฟอเรส', 'แม้ Forrest Gump จะมีร่างกายและสติปัญญาที่ไม่สมบูรณ์ ไม่มีพ่อตั้งแต่เด็ก แต่แม่พยายามสอนและเลี้ยงดูเขาแบบคนปกติ ไม่มองความผิดปกติของตัวเองเป็นปัญหา ทำให้เขาเป็นคนที่มีจิตใจงดงามและสมบูรณ์แบบแม้ร่างกายจะไม่สมบูรณ์แม่ของ Forrest Gump มักมีวิธีคิดและคำสอนง่ายๆที่ทำให้เขาเข้าใจได้เสมอ เหมือนประโยคเด็ดของเรื่องนี้อย่าง \" Life is like a box of chocolates. You never know what you are going to get. ', 'คนโง่ย่อมแสดงออกแบบโง่ๆ', '99.jpg'),
(2, 'ครอบครัวคือผู้ปลูกฝังทัศนคติที่ดี', 'แม้ Forrest Gump จะปล่อยชีวิตของเขาให้ล่องลอยไปตามโชคชะตา แต่เขาก็ยอมรับและเผชิญหน้ากับทุกสิ่งที่เข้ามา ทำมันอย่างทุ่มเท และยึดมั่นในสิ่งที่เชื่อ เหมือนกล่องช็อคโกแลตที่ถูกเปิดกินครบทุกรส และรองเท้าเลอะๆที่ผ่านเรื่องราวมามากมาย', 'คุณไม่มีทางรู้ว่าอะไรจะเกิดขึ้นกับคุณเพราะชีวิตเต็มไปด้วยสิ่งที่ไม่คาดคิด', '13.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `lanemark`
--

CREATE TABLE `lanemark` (
  `l_id` int(3) NOT NULL,
  `n_lanemark` varchar(60) NOT NULL,
  `detail` text NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `lanemark`
--

INSERT INTO `lanemark` (`l_id`, `n_lanemark`, `detail`, `image`) VALUES
(1, 'Forrest Gump Point', 'นี่คือที่ที่เขาวิ่งไปจนรู้สึกตัวว่าเขาเหนื่อยแล้วจากการที่เขาวิ่งมากไกลข้ามประเทศเพียงเพราะอยากวิ่ง', '10.jpg'),
(2, 'ทางเข้าบ้านฟอร์เรสท์', 'ทางเข้าบ้านของฟอเรสท์ซึ่งมีอยู่หลายฉากมากๆล้วนมีความทรงจำที่ดีและไม่ดี', '11.jpg'),
(3, 'ม้านั่งคอยรถ', 'ฉากนี้เป็นฉากเริ่มต้นเล่าเรื่องการผจญภัยของเขาตั้งแต่วัยเด็กจนถึงปัจจุบัน', '12.jpg'),
(4, 'บ้านฟอร์เรสท์', 'ฉากนี้เป็นตอนที่ฟอร์เรสท์กลับมาเยี่ยมแม่เนื่องจากเขาได้รับจดหมายว่าแม่ของเค้าป่วยอาการหนัก', '13.jpg'),
(5, 'สงครามที่เวียดนาม', 'เนื่องจากฟอร์เรสท์โดนใบแดงทบ.1จึงได้เข้ารับราชการทหารและถูกส่งตัวไปรบที่เวียดนามในหน่วยของทหารUSAซึ่งได้เจอกับบับบ้าและผู้หมวดแดน', '14.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl4`
--

CREATE TABLE `tbl4` (
  `a_id` int(11) NOT NULL,
  `name_1` varchar(100) NOT NULL,
  `image1` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl4`
--

INSERT INTO `tbl4` (`a_id`, `name_1`, `image1`) VALUES
(1, '-ฟอร์เรสท์ กัมพ์-', '56.jpg'),
(2, '-ฟอร์เรสท์ กัมพ์-', '09.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `actor`
--
ALTER TABLE `actor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `concept`
--
ALTER TABLE `concept`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `lanemark`
--
ALTER TABLE `lanemark`
  ADD PRIMARY KEY (`l_id`);

--
-- Indexes for table `tbl4`
--
ALTER TABLE `tbl4`
  ADD PRIMARY KEY (`a_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `actor`
--
ALTER TABLE `actor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `concept`
--
ALTER TABLE `concept`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `lanemark`
--
ALTER TABLE `lanemark`
  MODIFY `l_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl4`
--
ALTER TABLE `tbl4`
  MODIFY `a_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
